from tkinter import *
calc_root = Tk()

def click(event):
    global calcstring

    text=event.widget.cget("text")
    print(text)

    if text == "=":
        if calcstring.get().isdigit():
            calcvalue=int(calcstring.get())
        else:
            calcvalue=eval(calcscreen.get())
            calcstring.set(calcvalue)
            calcscreen.update()

    elif text == "DEL":
        calcstring.set("")
        calcscreen.update()
    else:
        calcstring.set(calcstring.get()+text)
        calcscreen.update()




calc_root.geometry("700x700")
calc_root.title("CALCULATOR")

calc_label = Label(text="PYTHON PROGRAMMING"
                        "\nTASK 2"
                        "\nCALCULATOR")
calc_label.pack()

calcstring = StringVar()
calcstring.set("")


calcscreen = Entry(calc_root, textvar=calcstring, font="lucida 40 bold")
calcscreen.pack(padx=20, pady=20)


calcframe = Frame(bg="black")

calcbuttons = Button(calcframe, text="1", padx=20, pady=20,  bg="white")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcbuttons = Button(calcframe, text="2", padx=20, pady=20,  bg="white")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcbuttons = Button(calcframe, text="3", padx=20, pady=20, bg="white")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcbuttons = Button(calcframe, text="/", padx=20, pady=20, bg="orange")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcframe.pack(padx=20, pady=20)

calcframe = Frame(bg="black")

calcbuttons = Button(calcframe, text="4", padx=20, pady=20,  bg="white")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcbuttons = Button(calcframe, text="5", padx=20, pady=20,  bg="white")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcbuttons = Button(calcframe, text="6", padx=20, pady=20, bg="white")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcbuttons = Button(calcframe, text="-", padx=20, pady=20, bg="orange")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcframe.pack(padx=20, pady=20)

calcframe = Frame(bg="black")

calcbuttons = Button(calcframe, text="7", padx=20, pady=20,  bg="white")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcbuttons = Button(calcframe, text="8", padx=20, pady=20,  bg="white")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcbuttons = Button(calcframe, text="9", padx=20, pady=20, bg="white")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcbuttons = Button(calcframe, text="+", padx=20, pady=20, bg="orange")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcframe.pack(padx=20, pady=20)


calcframe = Frame(bg="black")

calcbuttons = Button(calcframe, text="DEL", padx=20, pady=20,  bg="pink")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcbuttons = Button(calcframe, text="0", padx=20, pady=20,  bg="white")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcbuttons = Button(calcframe, text="=", padx=20, pady=20, bg="grey")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcbuttons = Button(calcframe, text="*", padx=20, pady=20, bg="orange")
calcbuttons.pack(side="left", padx=20, pady=20)
calcbuttons.bind("<Button-1> ", click)

calcframe.pack(padx=20, pady=20)

calc_root.mainloop()
